﻿using System;
using System.Diagnostics;
using System.IO;

namespace Recursividad
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var rutaInicial = Path.Combine("C:", "Carpetas");

            int totalElementos = ContarArchivosYCarpetas(rutaInicial);
            Console.WriteLine($"Total de archivos y carpetas: {totalElementos}");

            Console.WriteLine("Archivos con extensión .txt:");
            BuscarArchivosPorExtension(rutaInicial, ".txt");
        }
        //Función para carpetas.
        static int ContarArchivosYCarpetas(string ruta)
        {
            int contador = 0;

            try
            {
                contador += Directory.GetFiles(ruta).Length;

                foreach (string carpeta in Directory.GetDirectories(ruta))
                {
                    contador++;
                    contador += ContarArchivosYCarpetas(carpeta);
                }
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine($"Acceso denegado a la carpeta: {ruta}");
            }

            return contador;
        }
        //Función .txt
        static void BuscarArchivosPorExtension(string ruta, string extension)
        {
            try
            {
                foreach (string archivo in Directory.GetFiles(ruta))
                {
                    if (Path.GetExtension(archivo) == extension)
                    {
                        Console.WriteLine(archivo);
                    }
                }

                foreach (string carpeta in Directory.GetDirectories(ruta))
                {
                    BuscarArchivosPorExtension(carpeta, extension);
                }
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine($"Acceso denegado a la carpeta: {ruta}");
            }
        }
    }
}
