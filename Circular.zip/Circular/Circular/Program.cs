﻿using System;

namespace ListaCircular
{
    public class Nodo
    {
        public int Valor;
        public Nodo Siguiente;

        public Nodo(int valor)
        {
            Valor = valor;
            Siguiente = null;
        }
    }

    public class ListaCircular
    {
        private Nodo Cabeza;

        public ListaCircular()
        {
            Cabeza = null;
        }

        public void Agregar(int valor)
        {
            Nodo nuevoNodo = new Nodo(valor);
            if (Cabeza == null)
            {
                Cabeza = nuevoNodo;
                Cabeza.Siguiente = Cabeza;
            }
            else
            {
                Nodo actual = Cabeza;
                while (actual.Siguiente != Cabeza)
                {
                    actual = actual.Siguiente;
                }
                actual.Siguiente = nuevoNodo;
                nuevoNodo.Siguiente = Cabeza;
            }
        }

        public void Eliminar(int valor)
        {
            if (Cabeza == null)
            {
                Console.WriteLine("La lista está vacía.");
                return;
            }

            Nodo actual = Cabeza;
            Nodo anterior = null;

            do
            {
                if (actual.Valor == valor)
                {
                    if (anterior != null)
                    {
                        anterior.Siguiente = actual.Siguiente;
                        if (actual == Cabeza)
                            Cabeza = actual.Siguiente;
                    }
                    else
                    {
                        if (Cabeza.Siguiente == Cabeza)
                        {
                            Cabeza = null;
                        }
                        else
                        {
                            Nodo temp = Cabeza;
                            while (temp.Siguiente != Cabeza)
                            {
                                temp = temp.Siguiente;
                            }
                            temp.Siguiente = Cabeza.Siguiente;
                            Cabeza = Cabeza.Siguiente;
                        }
                    }
                    Console.WriteLine($"Valor {valor} eliminado.");
                    return;
                }
                anterior = actual;
                actual = actual.Siguiente;
            } while (actual != Cabeza);

            Console.WriteLine($"Valor {valor} no encontrado.");
        }

        public void Buscar(int valor)
        {
            if (Cabeza == null)
            {
                Console.WriteLine("La lista está vacía.");
                return;
            }

            Nodo actual = Cabeza;
            int posicion = 0;

            do
            {
                if (actual.Valor == valor)
                {
                    Console.WriteLine($"Valor {valor} encontrado en la posición {posicion}.");
                    return;
                }
                actual = actual.Siguiente;
                posicion++;
            } while (actual != Cabeza);

            Console.WriteLine($"Valor {valor} no encontrado.");
        }

        public void Modificar(int valorViejo, int valorNuevo)
        {
            if (Cabeza == null)
            {
                Console.WriteLine("La lista está vacía.");
                return;
            }

            Nodo actual = Cabeza;

            do
            {
                if (actual.Valor == valorViejo)
                {
                    actual.Valor = valorNuevo;
                    Console.WriteLine($"Valor {valorViejo} modificado a {valorNuevo}.");
                    return;
                }
                actual = actual.Siguiente;
            } while (actual != Cabeza);

            Console.WriteLine($"Valor {valorViejo} no encontrado.");
        }

        public void Imprimir()
        {
            if (Cabeza == null)
            {
                Console.WriteLine("La lista está vacía.");
                return;
            }

            Nodo actual = Cabeza;

            Console.WriteLine("Lista circular:");
            do
            {
                Console.Write(actual.Valor + " ");
                actual = actual.Siguiente;
            } while (actual != Cabeza);

            Console.WriteLine();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            ListaCircular lista = new ListaCircular();
            int opcion;

            do
            {
                Console.WriteLine("\n--- Lista Circular ---");
                Console.WriteLine("1. Agregar");
                Console.WriteLine("2. Eliminar");
                Console.WriteLine("3. Buscar");
                Console.WriteLine("4. Modificar");
                Console.WriteLine("5. Imprimir lista");
                Console.WriteLine("0. Salir");
                Console.Write("Elija una opción: ");
                opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        Console.Write("Ingrese el valor a agregar: ");
                        int valorAgregar = int.Parse(Console.ReadLine());
                        lista.Agregar(valorAgregar);
                        break;
                    case 2:
                        Console.Write("Ingrese el valor a eliminar: ");
                        int valorEliminar = int.Parse(Console.ReadLine());
                        lista.Eliminar(valorEliminar);
                        break;
                    case 3:
                        Console.Write("Ingrese el valor a buscar: ");
                        int valorBuscar = int.Parse(Console.ReadLine());
                        lista.Buscar(valorBuscar);
                        break;
                    case 4:
                        Console.Write("Ingrese el valor a modificar: ");
                        int valorModificar = int.Parse(Console.ReadLine());
                        Console.Write("Ingrese el nuevo valor: ");
                        int nuevoValor = int.Parse(Console.ReadLine());
                        lista.Modificar(valorModificar, nuevoValor);
                        break;
                    case 5:
                        lista.Imprimir();
                        break;
                    case 0:
                        Console.WriteLine("Saliendo...");
                        break;
                    default:
                        Console.WriteLine("Opción inválida.");
                        break;
                }
            } while (opcion != 0);
        }
    }
}
