﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionBiblioteca.Modelos
{
    public class LibroElectronico : Libro
    {
        public string Formato { get; set; }
        public double TamañoArchivo { get; set; }

        public LibroElectronico(string titulo, string autor, int año, string formato, double tamañoArchivo)
            : base(titulo, autor, año)
        {
            Formato = formato;
            TamañoArchivo = tamañoArchivo;
        }
    }
}
