﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionBiblioteca.Modelos
{
    public class PrestamoFisico : Prestamo
    {
        public LibroFisico LibroPrestado { get; set; }

        public PrestamoFisico(LibroFisico libro)
        {
            LibroPrestado = libro;
        }

        public override void RealizarPrestamo()
        {
            base.RealizarPrestamo();
            Console.WriteLine($"Libro físico '{LibroPrestado.Titulo}' prestado hasta {FechaDevolucion}");
        }
    }
}
