﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionBiblioteca.Modelos
{
    public class PrestamoElectronico : Prestamo
    {
        public LibroElectronico LibroPrestado { get; set; }

        public PrestamoElectronico(LibroElectronico libro)
        {
            LibroPrestado = libro;
        }

        public override void RealizarPrestamo()
        {
            base.RealizarPrestamo();
            Console.WriteLine($"Libro electrónico '{LibroPrestado.Titulo}' prestado hasta {FechaDevolucion}");
        }
    }
}
