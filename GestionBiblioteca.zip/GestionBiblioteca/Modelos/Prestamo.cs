﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionBiblioteca.Modelos
{
    public class Prestamo
    {
        public DateTime FechaPrestamo { get; set; }
        public DateTime FechaDevolucion { get; set; }
        public Libro Libro { get; internal set; }
        internal Miembro Miembro { get; set; }

        public virtual void RealizarPrestamo()
        {
            FechaPrestamo = DateTime.Now;
            FechaDevolucion = FechaPrestamo.AddDays(14);
        }
    }
}
