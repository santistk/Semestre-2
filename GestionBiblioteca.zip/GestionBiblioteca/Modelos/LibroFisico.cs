﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionBiblioteca.Modelos
{
    public class LibroFisico : Libro
    {
        public string Ubicacion { get; set; }

        public LibroFisico(string titulo, string autor, int año, string ubicacion)
            : base(titulo, autor, año)
        {
            Ubicacion = ubicacion;
        }
    }
}
