﻿namespace GestionBiblioteca
{
    internal class Miembro
    {
        public string Nombre { get; internal set; }
        public int NumeroMiembro { get; internal set; }
    }
}