﻿using System;

class LaberintoSolver
{
    public static bool EncontrarCamino(int[][] laberinto, int filaInicial, int columnaInicial, int filaFinal, int columnaFinal)
    {
        if (filaInicial < 0 || columnaInicial < 0 || filaInicial >= laberinto.Length || columnaInicial >= laberinto[0].Length)
            return false;

        if (filaInicial == filaFinal && columnaInicial == columnaFinal && laberinto[filaInicial][columnaInicial] == 0)
            return true;

        if (laberinto[filaInicial][columnaInicial] != 0)
            return false;

        laberinto[filaInicial][columnaInicial] = -1;

        if (EncontrarCamino(laberinto, filaInicial - 1, columnaInicial, filaFinal, columnaFinal))
            return true;
        if (EncontrarCamino(laberinto, filaInicial + 1, columnaInicial, filaFinal, columnaFinal))
            return true;
        if (EncontrarCamino(laberinto, filaInicial, columnaInicial - 1, filaFinal, columnaFinal))
            return true;
        if (EncontrarCamino(laberinto, filaInicial, columnaInicial + 1, filaFinal, columnaFinal))
            return true;

        laberinto[filaInicial][columnaInicial] = 0;

        return false;
    }

    static void Main(string[] args)
    {
        int[][] laberinto1 = new int[][]
        {
            new int[] { 0, 1, 0, 0, 0 },
            new int[] { 0, 1, 1, 1, 0 },
            new int[] { 0, 0, 0, 1, 0 },
            new int[] { 1, 1, 0, 1, 1 },
            new int[] { 0, 0, 0, 0, 0 }
        };

        Console.WriteLine("Laberinto 1: " + EncontrarCamino(laberinto1, 0, 0, 4, 4));

        int[][] laberinto2 = new int[][]
        {
            new int[] { 0, 0, 1, 1, 1, 0, 0, 0 },
            new int[] { 1, 0, 1, 0, 0, 0, 1, 1 },
            new int[] { 1, 0, 0, 0, 1, 1, 0, 1 },
            new int[] { 0, 1, 1, 1, 0, 0, 0, 0 },
            new int[] { 0, 0, 0, 1, 1, 1, 1, 0 },
            new int[] { 1, 1, 0, 0, 0, 0, 1, 0 },
            new int[] { 0, 1, 1, 1, 0, 1, 0, 0 },
            new int[] { 0, 0, 0, 0, 0, 1, 1, 0 }
        };

        Console.WriteLine("Laberinto 2: " + EncontrarCamino(laberinto2, 0, 0, 7, 4));

        int[][] laberinto3 = new int[][]
        {
            new int[] { 0, 1, 0, 0, 0, 1, 0, 0, 0, 1 },
            new int[] { 0, 1, 1, 1, 0, 1, 1, 1, 0, 1 },
            new int[] { 0, 0, 0, 1, 0, 0, 0, 1, 0, 1 },
            new int[] { 1, 1, 0, 1, 1, 1, 0, 0, 0, 0 },
            new int[] { 0, 0, 0, 0, 0, 1, 1, 1, 1, 0 },
            new int[] { 1, 1, 1, 1, 0, 0, 0, 0, 0, 0 },
            new int[] { 0, 1, 1, 1, 1, 1, 1, 1, 1, 0 },
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 1, 0 },
            new int[] { 1, 1, 1, 1, 1, 1, 1, 0, 1, 0 },
            new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
        };

        Console.WriteLine("Laberinto 3: " + EncontrarCamino(laberinto3, 0, 0, 9, 9));
    }
}
