﻿namespace ManejoEventos1._0
{
    internal class txtNombreTareas
    {
    }
}