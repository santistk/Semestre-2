﻿using System;
using System.Windows.Forms;

namespace ManejoEventos1._0
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        private void InitializeComponent()
        {
            this.textNombreTarea = new System.Windows.Forms.TextBox();
            this.flowPanelTareasPendientes = new System.Windows.Forms.FlowLayoutPanel();
            this.flowPanelTareasEnProgreso = new System.Windows.Forms.FlowLayoutPanel();
            this.flowPanelTareasCompletadas = new System.Windows.Forms.FlowLayoutPanel();
            this.comboEstado = new System.Windows.Forms.ComboBox();
            this.buttonAgregarTarea = new System.Windows.Forms.Button();
            this.buttonEliminarUltimaTarea = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textNombreTarea
            // 
            this.textNombreTarea.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textNombreTarea.Location = new System.Drawing.Point(20, 20);
            this.textNombreTarea.Name = "textNombreTarea";
            this.textNombreTarea.Size = new System.Drawing.Size(350, 22);
            this.textNombreTarea.TabIndex = 0;
            // 
            // flowPanelTareasPendientes
            // 
            this.flowPanelTareasPendientes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.flowPanelTareasPendientes.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowPanelTareasPendientes.Location = new System.Drawing.Point(20, 60);
            this.flowPanelTareasPendientes.Name = "flowPanelTareasPendientes";
            this.flowPanelTareasPendientes.Size = new System.Drawing.Size(300, 400);
            this.flowPanelTareasPendientes.TabIndex = 1;
            // 
            // flowPanelTareasEnProgreso
            // 
            this.flowPanelTareasEnProgreso.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.flowPanelTareasEnProgreso.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowPanelTareasEnProgreso.Location = new System.Drawing.Point(340, 60);
            this.flowPanelTareasEnProgreso.Name = "flowPanelTareasEnProgreso";
            this.flowPanelTareasEnProgreso.Size = new System.Drawing.Size(300, 400);
            this.flowPanelTareasEnProgreso.TabIndex = 2;
            // 
            // flowPanelTareasCompletadas
            // 
            this.flowPanelTareasCompletadas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.flowPanelTareasCompletadas.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowPanelTareasCompletadas.Location = new System.Drawing.Point(660, 60);
            this.flowPanelTareasCompletadas.Name = "flowPanelTareasCompletadas";
            this.flowPanelTareasCompletadas.Size = new System.Drawing.Size(300, 400);
            this.flowPanelTareasCompletadas.TabIndex = 3;
            // 
            // comboEstado
            // 
            this.comboEstado.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.comboEstado.FormattingEnabled = true;
            this.comboEstado.Items.AddRange(new object[] {
            "Sin Empezar",
            "En Progreso",
            "Completada"});
            this.comboEstado.Location = new System.Drawing.Point(380, 20);
            this.comboEstado.Name = "comboEstado";
            this.comboEstado.Size = new System.Drawing.Size(150, 24);
            this.comboEstado.TabIndex = 4;
            // 
            // buttonAgregarTarea
            // 
            this.buttonAgregarTarea.BackColor = System.Drawing.Color.Cyan;
            this.buttonAgregarTarea.Location = new System.Drawing.Point(540, 20);
            this.buttonAgregarTarea.Name = "buttonAgregarTarea";
            this.buttonAgregarTarea.Size = new System.Drawing.Size(120, 30);
            this.buttonAgregarTarea.TabIndex = 5;
            this.buttonAgregarTarea.Text = "Agregar";
            this.buttonAgregarTarea.UseVisualStyleBackColor = false;
            this.buttonAgregarTarea.Click += new System.EventHandler(this.AgregarTarea);
            // 
            // buttonEliminarUltimaTarea
            // 
            this.buttonEliminarUltimaTarea.BackColor = System.Drawing.Color.Red;
            this.buttonEliminarUltimaTarea.Location = new System.Drawing.Point(670, 470);
            this.buttonEliminarUltimaTarea.Name = "buttonEliminarUltimaTarea";
            this.buttonEliminarUltimaTarea.Size = new System.Drawing.Size(212, 30);
            this.buttonEliminarUltimaTarea.TabIndex = 6;
            this.buttonEliminarUltimaTarea.Text = "Eliminar Última";
            this.buttonEliminarUltimaTarea.UseVisualStyleBackColor = false;
            this.buttonEliminarUltimaTarea.Click += new System.EventHandler(this.EliminarUltimaTarea);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(980, 520);
            this.Controls.Add(this.buttonEliminarUltimaTarea);
            this.Controls.Add(this.buttonAgregarTarea);
            this.Controls.Add(this.comboEstado);
            this.Controls.Add(this.flowPanelTareasCompletadas);
            this.Controls.Add(this.flowPanelTareasEnProgreso);
            this.Controls.Add(this.flowPanelTareasPendientes);
            this.Controls.Add(this.textNombreTarea);
            this.Name = "Form1";
            this.Text = "Gestor de Tareas";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox textNombreTarea;
        private FlowLayoutPanel flowPanelTareasPendientes;
        private FlowLayoutPanel flowPanelTareasEnProgreso;
        private FlowLayoutPanel flowPanelTareasCompletadas;
        private ComboBox comboEstado;
        private Button buttonAgregarTarea;
        private Button buttonEliminarUltimaTarea;
    }
}
