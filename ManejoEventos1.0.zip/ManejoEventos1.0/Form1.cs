﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ManejoEventos1._0
{
    public partial class Form1 : Form
    {
        private List<Tarea> tareas;

        public Form1()
        {
            InitializeComponent();
            tareas = new List<Tarea>();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Opcional: Inicializa o carga datos cuando el formulario se carga
            RenderizarTareas();
        }

        private void AgregarTarea(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textNombreTarea.Text))
            {
                MessageBox.Show("Debe agregar un nombre para la tarea");
                return;
            }

            string estadoSeleccionado = comboEstado.SelectedItem?.ToString() ?? "Sin Empezar";
            Tarea nuevaTarea = new Tarea(textNombreTarea.Text, estadoSeleccionado);
            tareas.Add(nuevaTarea);
            textNombreTarea.Clear();

            RenderizarTareas();
        }
        private void EliminarUltimaTarea(object sender, EventArgs e)
        {
            if (tareas.Count > 0)
            {
                tareas.RemoveAt(tareas.Count - 1);
                RenderizarTareas();
            }
            else
            {
                MessageBox.Show("No hay tareas para eliminar.");
            }
        }

        private void RenderizarTareas()
        {
            flowPanelTareasPendientes.Controls.Clear();
            flowPanelTareasEnProgreso.Controls.Clear();
            flowPanelTareasCompletadas.Controls.Clear();

            foreach (Tarea tarea in tareas)
            {
                Label tarjeta = new Label
                {
                    Text = tarea.Nombre,
                    AutoSize = true,
                    Padding = new Padding(10),
                    Margin = new Padding(5),
                    BackColor = Color.White,
                    ForeColor = Color.Black,
                    BorderStyle = BorderStyle.FixedSingle
                };

                tarjeta.DoubleClick += (sender, e) =>
                {
                    if (tarea.Estado == "Sin Empezar")
                    {
                        tareas.Remove(tarea);
                    }
                    else if (tarea.Estado == "En Progreso")
                    {
                        tarea.Estado = "Completada";
                    }

                    RenderizarTareas();
                };

                tarjeta.MouseHover += (sender, e) =>
                {
                    tarjeta.BackColor = Color.LightGray;
                    tarjeta.Font = new Font(tarjeta.Font, FontStyle.Bold);
                    tarjeta.Cursor = Cursors.Hand;
                };

                tarjeta.MouseLeave += (sender, e) =>
                {
                    tarjeta.BackColor = Color.White;
                    tarjeta.Font = new Font(tarjeta.Font, FontStyle.Regular);
                };

                switch (tarea.Estado)
                {
                    case "Sin Empezar":
                        flowPanelTareasPendientes.Controls.Add(tarjeta);
                        break;
                    case "En Progreso":
                        flowPanelTareasEnProgreso.Controls.Add(tarjeta);
                        break;
                    case "Completada":
                        flowPanelTareasCompletadas.Controls.Add(tarjeta);
                        break;
                }
            }
        }

        internal class Tarea
        {
            public string Nombre { get; set; }
            public string Estado { get; set; }

            public Tarea(string nombre, string estado)
            {
                Nombre = nombre;
                Estado = estado;
            }
        }
    }
}
