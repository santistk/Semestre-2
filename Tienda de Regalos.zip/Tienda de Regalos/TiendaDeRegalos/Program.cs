﻿using System;
using System.Linq;
using System.Collections.Generic;
using TiendaDeRegalos.Modelos;
using TiendaDeRegalos.Servicios;

namespace TiendaDeRegalos
{
    class Program
    {
        static InventarioService inventarioService = new InventarioService();
        static CarritoCompraService carritoCompraService = new CarritoCompraService();
        static HistorialTransaccionesService historialTransaccionesService = new HistorialTransaccionesService();

        static void Main(string[] args)
        {
            bool ejecutar = true;

            while (ejecutar)
            {
                MostrarMenuPrincipal();
                int opcion = Convert.ToInt32(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        MenuAgregarProducto();
                        break;
                    case 2:
                        MenuEliminarProducto();
                        break;
                    case 3:
                        MenuActualizarInventario();
                        break;
                    case 4:
                        MenuRealizarCompra();
                        break;
                    case 5:
                        VerHistorialTransacciones();
                        break;
                    case 6:
                        ejecutar = false;
                        break;
                    default:
                        Console.WriteLine("Opción no válida.");
                        break;
                }
            }
        }

        static void MostrarMenuPrincipal()
        {
            Console.WriteLine("\n--- Menú Principal ---");
            Console.WriteLine("1. Agregar Producto");
            Console.WriteLine("2. Eliminar Producto");
            Console.WriteLine("3. Actualizar Inventario");
            Console.WriteLine("4. Realizar Compra");
            Console.WriteLine("5. Ver Historial de Transacciones");
            Console.WriteLine("6. Salir");
            Console.Write("Selecciona una opción: ");
        }

        static void MenuAgregarProducto()
        {
            Console.Write("Nombre del producto: ");
            string nombre = Console.ReadLine();

            Console.Write("Precio del producto: ");
            decimal precio = Convert.ToDecimal(Console.ReadLine());

            Console.Write("Cantidad del producto: ");
            int cantidad = Convert.ToInt32(Console.ReadLine());

            inventarioService.AgregarProducto(new Producto(nombre, precio, cantidad));
            Console.WriteLine("Producto agregado correctamente.");
        }

        static void MenuEliminarProducto()
        {
            Console.Write("Nombre del producto a eliminar: ");
            string nombreProducto = Console.ReadLine();

            if (inventarioService.EliminarProducto(nombreProducto))
            {
                Console.WriteLine("Producto eliminado correctamente.");
            }
            else
            {
                Console.WriteLine("Producto no encontrado.");
            }
        }

        static void MenuActualizarInventario()
        {
            Console.Write("Nombre del producto a actualizar: ");
            string nombreProducto = Console.ReadLine();

            Console.Write("Nueva cantidad: ");
            int nuevaCantidad = Convert.ToInt32(Console.ReadLine());

            if (inventarioService.ActualizarInventario(nombreProducto, nuevaCantidad))
            {
                Console.WriteLine("Inventario actualizado correctamente.");
            }
            else
            {
                Console.WriteLine("Producto no encontrado.");
            }
        }

        static void MenuRealizarCompra()
        {
            Console.WriteLine("--- Productos Disponibles ---");
            var inventario = inventarioService.ObtenerInventario();

            if (inventario.Count == 0)
            {
                Console.WriteLine("No hay productos disponibles.");
                return;
            }

            foreach (var producto in inventario)
            {
                Console.WriteLine(producto);
            }

            while (true)
            {
                Console.Write("Nombre del producto a comprar (o escribe 'fin' para terminar): ");
                string nombreProducto = Console.ReadLine();

                if (nombreProducto.ToLower() == "fin")
                {
                    break;
                }

                var producto = inventario.FirstOrDefault(p => p.Nombre.Equals(nombreProducto, StringComparison.OrdinalIgnoreCase));

                if (producto == null)
                {
                    Console.WriteLine("Producto no encontrado.");
                    continue;
                }

                Console.Write("Cantidad a comprar: ");
                int cantidad = Convert.ToInt32(Console.ReadLine());

                if (cantidad > producto.Cantidad)
                {
                    Console.WriteLine($"Cantidad no disponible. Solo hay {producto.Cantidad} en inventario.");
                }
                else
                {
                    carritoCompraService.AgregarAlCarrito(producto, cantidad);
                    producto.Cantidad -= cantidad;
                    Console.WriteLine("Producto agregado al carrito.");
                }
            }

            decimal total = carritoCompraService.CalcularTotal();
            if (total > 0)
            {
                Console.WriteLine($"Total de la compra (incluye 12% de impuestos): Q{total}");
                historialTransaccionesService.RegistrarTransaccion(carritoCompraService.ObtenerCarrito(), total);
                carritoCompraService.VaciarCarrito();
                Console.WriteLine("Compra realizada con éxito.");
            }
            else
            {
                Console.WriteLine("No se realizó ninguna compra.");
            }
        }

        static void VerHistorialTransacciones()
        {
            Console.WriteLine("--- Historial de Transacciones ---");
            var historial = historialTransaccionesService.ObtenerHistorial();

            if (historial.Count == 0)
            {
                Console.WriteLine("No hay transacciones registradas.");
            }
            else
            {
                foreach (var transaccion in historial)
                {
                    Console.WriteLine(transaccion);
                }
            }
        }
    }
}
