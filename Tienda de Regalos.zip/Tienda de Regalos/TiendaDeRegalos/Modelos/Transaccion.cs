﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiendaDeRegalos.Modelos
{
    public class Transaccion
    {
        public List<Producto> Productos { get; set; }
        public DateTime Fecha { get; set; }
        public decimal Total { get; set; }

        public Transaccion(List<Producto> productos, decimal total)
        {
            Productos = productos;
            Fecha = DateTime.Now;
            Total = total;
        }

        public override string ToString()
        {
            string productosComprados = string.Join(", ", Productos.Select(p => $"{p.Nombre} x {p.Cantidad}"));
            return $"Fecha: {Fecha}, Productos: {productosComprados}, Total: Q{Total}";
        }
    }
}
