﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TiendaDeRegalos.Modelos;

namespace TiendaDeRegalos.Servicios
{
    public class InventarioService
    {
        private List<Producto> productos = new List<Producto>();

        public InventarioService()
        {
            
            productos.Add(new Producto("HotWheels", 20.00m, 50));
            productos.Add(new Producto("Pelotas de fútbol", 350.00m, 20));
            productos.Add(new Producto("Guitarras", 1200.00m, 10));
            productos.Add(new Producto("Carros a control remoto", 400.00m, 15));
            productos.Add(new Producto("Carros de drift a escala", 750.00m, 10));
            productos.Add(new Producto("Muñecas Barbie", 15.00m, 100));
            productos.Add(new Producto("Muñecas Bratz", 250.00m, 30));
            productos.Add(new Producto("Relojes", 1000.00m, 10));
            productos.Add(new Producto("Zapatillas", 350.00m, 20));
            productos.Add(new Producto("Tenis deportivos", 550.00m, 25));
            productos.Add(new Producto("Tenis casuales", 500.00m, 25));
            productos.Add(new Producto("Camisas", 100.00m, 50));
            productos.Add(new Producto("Blusas", 75.00m, 60));
            productos.Add(new Producto("Blusas deportivas", 200.00m, 30));
            productos.Add(new Producto("Playeras", 50.00m, 100));
            productos.Add(new Producto("Playeras deportivas", 100.00m, 40));
            productos.Add(new Producto("Pants para dormir", 75.00m, 50));
            productos.Add(new Producto("Pants deportivos", 75.00m, 50));
        }

        public List<Producto> ObtenerInventario()
        {
            return productos;
        }

        public void AgregarProducto(Producto producto)
        {
            productos.Add(producto);
        }

        public bool EliminarProducto(string nombreProducto)
        {
            var producto = productos.FirstOrDefault(p => p.Nombre == nombreProducto);
            if (producto != null)
            {
                productos.Remove(producto);
                return true;
            }
            return false;
        }

        public bool ActualizarInventario(string nombreProducto, int nuevaCantidad)
        {
            var producto = productos.FirstOrDefault(p => p.Nombre == nombreProducto);
            if (producto != null)
            {
                producto.Cantidad = nuevaCantidad;
                return true;
            }
            return false;
        }
    }
}
