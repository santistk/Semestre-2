﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TiendaDeRegalos.Modelos;

namespace TiendaDeRegalos.Servicios
{
    public class HistorialTransaccionesService
    {
        private List<Transaccion> historialTransacciones = new List<Transaccion>();

        public void RegistrarTransaccion(List<Producto> productos, decimal total)
        {
            historialTransacciones.Add(new Transaccion(productos, total));
        }

        public List<Transaccion> ObtenerHistorial()
        {
            return historialTransacciones;
        }
    }
}
