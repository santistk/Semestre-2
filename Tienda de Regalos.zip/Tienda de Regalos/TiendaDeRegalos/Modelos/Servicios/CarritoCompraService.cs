﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TiendaDeRegalos.Modelos;

namespace TiendaDeRegalos.Servicios
{
    public class CarritoCompraService
    {
        private List<Producto> carrito = new List<Producto>();

        public void AgregarAlCarrito(Producto producto, int cantidad)
        {
            var itemCarrito = carrito.FirstOrDefault(p => p.Nombre == producto.Nombre);
            if (itemCarrito == null)
            {
                carrito.Add(new Producto(producto.Nombre, producto.Precio, cantidad));
            }
            else
            {
                itemCarrito.Cantidad += cantidad;
            }
        }

        public decimal CalcularTotal()
        {
            decimal subtotal = carrito.Sum(p => p.Precio * p.Cantidad);
            decimal total = subtotal * 1.12m;  // Incluir impuesto del 12%
            return total;
        }

        public List<Producto> ObtenerCarrito()
        {
            return carrito;
        }

        public void VaciarCarrito()
        {
            carrito.Clear();
        }
    }
}
