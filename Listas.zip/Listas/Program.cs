﻿using System;

namespace ListaDoblementeEnlazada
{
    public class Nodo
    {
        public int Valor;
        public Nodo Anterior;
        public Nodo Siguiente;

        public Nodo(int valor)
        {
            Valor = valor;
            Anterior = null;
            Siguiente = null;
        }
    }

    public class ListaDoblementeEnlazada
    {
        private Nodo Cabeza;
        private Nodo Cola;

        public ListaDoblementeEnlazada()
        {
            Cabeza = null;
            Cola = null;
        }

        public void Agregar(int valor)
        {
            Nodo nuevoNodo = new Nodo(valor);
            if (Cabeza == null)
            {
                Cabeza = nuevoNodo;
                Cola = nuevoNodo;
            }
            else
            {
                Cola.Siguiente = nuevoNodo;
                nuevoNodo.Anterior = Cola;
                Cola = nuevoNodo;
            }
        }

        public void Eliminar(int valor)
        {
            Nodo actual = Cabeza;

            while (actual != null)
            {
                if (actual.Valor == valor)
                {
                    if (actual.Anterior != null)
                        actual.Anterior.Siguiente = actual.Siguiente;
                    else
                        Cabeza = actual.Siguiente;

                    if (actual.Siguiente != null)
                        actual.Siguiente.Anterior = actual.Anterior;
                    else
                        Cola = actual.Anterior;

                    Console.WriteLine($"Valor {valor} eliminado.");
                    return;
                }
                actual = actual.Siguiente;
            }

            Console.WriteLine($"Valor {valor} no encontrado.");
        }

        public void Buscar(int valor)
        {
            Nodo actual = Cabeza;
            int posicion = 0;

            while (actual != null)
            {
                if (actual.Valor == valor)
                {
                    Console.WriteLine($"Valor {valor} encontrado en posición {posicion}.");
                    return;
                }
                actual = actual.Siguiente;
                posicion++;
            }

            Console.WriteLine($"Valor {valor} no encontrado.");
        }

        public void Modificar(int valorViejo, int valorNuevo)
        {
            Nodo actual = Cabeza;

            while (actual != null)
            {
                if (actual.Valor == valorViejo)
                {
                    actual.Valor = valorNuevo;
                    Console.WriteLine($"Valor {valorViejo} modificado a {valorNuevo}.");
                    return;
                }
                actual = actual.Siguiente;
            }

            Console.WriteLine($"Valor {valorViejo} no encontrado.");
        }

        public void ImprimirHaciaAdelante()
        {
            Nodo actual = Cabeza;

            Console.WriteLine("Lista hacia adelante:");
            while (actual != null)
            {
                Console.Write(actual.Valor + " ");
                actual = actual.Siguiente;
            }
            Console.WriteLine();
        }

        public void ImprimirHaciaAtras()
        {
            Nodo actual = Cola;

            Console.WriteLine("Lista hacia atrás:");
            while (actual != null)
            {
                Console.Write(actual.Valor + " ");
                actual = actual.Anterior;
            }
            Console.WriteLine();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            ListaDoblementeEnlazada lista = new ListaDoblementeEnlazada();
            int opcion;

            do
            {
                Console.WriteLine("\n--- Lista Doblemente Enlazada ---");
                Console.WriteLine("1. Agregar");
                Console.WriteLine("2. Eliminar");
                Console.WriteLine("3. Buscar");
                Console.WriteLine("4. Modificar");
                Console.WriteLine("5. Imprimir hacia adelante");
                Console.WriteLine("6. Imprimir hacia atrás");
                Console.WriteLine("0. Salir");
                Console.Write("Elija una opción: ");
                opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        Console.Write("Ingrese el valor a agregar: ");
                        int valorAgregar = int.Parse(Console.ReadLine());
                        lista.Agregar(valorAgregar);
                        break;
                    case 2:
                        Console.Write("Ingrese el valor a eliminar: ");
                        int valorEliminar = int.Parse(Console.ReadLine());
                        lista.Eliminar(valorEliminar);
                        break;
                    case 3:
                        Console.Write("Ingrese el valor a buscar: ");
                        int valorBuscar = int.Parse(Console.ReadLine());
                        lista.Buscar(valorBuscar);
                        break;
                    case 4:
                        Console.Write("Ingrese el valor a modificar: ");
                        int valorModificar = int.Parse(Console.ReadLine());
                        Console.Write("Ingrese el nuevo valor: ");
                        int nuevoValor = int.Parse(Console.ReadLine());
                        lista.Modificar(valorModificar, nuevoValor);
                        break;
                    case 5:
                        lista.ImprimirHaciaAdelante();
                        break;
                    case 6:
                        lista.ImprimirHaciaAtras();
                        break;
                    case 0:
                        Console.WriteLine("Saliendo...");
                        break;
                    default:
                        Console.WriteLine("Opción inválida.");
                        break;
                }
            } while (opcion != 0);
        }
    }
}
