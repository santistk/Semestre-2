using App.Entidades;
using NUnit.Framework;
using System;

namespace Tests
{
    public class Tests
    {
        private Biblioteca _biblioteca;
        private Libro _libro1;
        private Libro _libro2;

        [SetUp]
        public void Setup()
        {
            _biblioteca = new Biblioteca();
            _libro1 = new Libro("1984", "George Orwell");
            _libro2 = new Libro("El Principito", "Antoine de Saint-Exup�ry");
            _biblioteca.AgregarLibro(_libro1);
            _biblioteca.AgregarLibro(_libro2);
        }

        [Test]
        public void PrestarLibro_LibroDisponible_PrestaLibroCorrectamente()
        {
            // Act
            _biblioteca.PrestarLibro(_libro1.Titulo);

            // Assert
            Assert.IsTrue(_libro1.EstaPrestado, "El libro deber�a estar prestado.");
        }

        [Test]
        public void PrestarLibro_LibroNoDisponible_LanzaExcepcion()
        {
            // Arrange
            _biblioteca.PrestarLibro(_libro1.Titulo);

            // Act & Assert
            var ex = Assert.Throws<Exception>(() => _biblioteca.PrestarLibro(_libro1.Titulo));
            Assert.AreEqual("El libro ya est� prestado.", ex.Message);
        }

        [Test]
        public void DevolverLibro_LibroPrestado_DevolveLibroCorrectamente()
        {
            // Arrange
            _biblioteca.PrestarLibro(_libro1.Titulo);

            // Act
            _biblioteca.DevolverLibro(_libro1.Titulo);

            // Assert
            Assert.IsFalse(_libro1.EstaPrestado, "El libro deber�a estar disponible.");
        }

        [Test]
        public void DevolverLibro_LibroNoPrestado_LanzaExcepcion()
        {
            // Act & Assert
            var ex = Assert.Throws<Exception>(() => _biblioteca.DevolverLibro(_libro1.Titulo));
            Assert.AreEqual("El libro no est� prestado.", ex.Message);
        }

        [Test]
        public void ObtenerLibros_RetornaListaDeLibros()
        {
            // Act
            var libros = _biblioteca.ObtenerLibros();

            // Assert
            Assert.AreEqual(2, libros.Count, "Deber�a haber 2 libros en la biblioteca.");
            Assert.Contains(_libro1, libros, "La biblioteca deber�a contener el libro 1984.");
            Assert.Contains(_libro2, libros, "La biblioteca deber�a contener el libro El Principito.");
        }
    }
}
